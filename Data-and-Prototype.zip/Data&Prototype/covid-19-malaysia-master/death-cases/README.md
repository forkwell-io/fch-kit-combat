## Notes on Malaysia COVID-19 death cases data

1. Most of the data are taken directly from the Desk of DG website.
2. Case numbers are based on the date reported by MOH, not by the date of death of patient.
3. For the history column, the unfilled one can imply for local transmission, under invesigation or undisclosed.
4. 'y' in 'chronic' means that the patient had a past medical history of chronic diseases. Data provided on earlier cases *may or may not* be accurate.
5. Not all treatment date and patient history are given out by MOH. You can help search for offical sources / news site to help fill it in.
6. A few patient such as 5 and 39 passed away at home before getting treatment / treated and had went back home.
7. The data provided is fully for educational / analytical purposes.

🕯️ **May those who had lost in the battle rest in peace.**
