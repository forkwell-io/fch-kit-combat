The states that do not have any districts are Perlis, Putrajaya and WP Labuan.
You may refer to their cases in states/covid-19-my-states-cases.csv
