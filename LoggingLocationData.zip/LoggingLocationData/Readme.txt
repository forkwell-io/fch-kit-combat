This folder demonstrates how location of a user is consistantly tracked.

apk file: .\AndroidStudio\app\build\outputs\apk\debug\app-debug.apk
Example of data logged: DataExample.png

Permissions needed in the app: Location, Internet.